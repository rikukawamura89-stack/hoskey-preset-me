﻿; ==============================================================================
; Nama Script : Shortcut Riku v4.0 (Ultimate Edition)
; Pembuat     : Riku
; Deskripsi   : Power Instan, Media Control Universal (7,4,1), & System Control.
; Versi       : 4.0 - Anti-Conflict & Auto-Admin
; ==============================================================================

#Requires AutoHotkey v2.0
#SingleInstance Force

; --- [ OTOMATISASI STARTUP ] ---

; Jalankan sebagai Admin agar perintah sistem lebih responsif
if !A_IsAdmin {
    Run('*RunAs "' . A_ScriptFullPath . '"')
    ExitApp
}

; Pastikan NumLock selalu ON saat script jalan (biar Numpad siap pakai)
SetNumLockState "AlwaysOn"

; --- [ POWER & SYSTEM CONTROLS - INSTAN ] ---

; 😴 Sleep Mode → RWin + F1
RWin & F1:: {
    DllCall("PowrProf\SetSuspendState", "Int", 0, "Int", 0, "Int", 0)
}

; 🔒 Lock Screen → RWin + F2
RWin & F2:: {
    DllCall("LockWorkStation")
}

; 🔄 Restart System → RWin + F5 (Instan)
RWin & F5:: {
    Shutdown(6) ; 2 (Restart) + 4 (Force)
}

; ⏻ Shutdown → RWin + Esc (Instan)
RWin & Esc:: {
    Shutdown(5) ; 1 (Shutdown) + 4 (Force)
}

; --- [ MEDIA CONTROLS - NUMPAD 7, 4, 1 ] ---
; Dibuat ganda agar tetap jalan mau NumLock ON (Angka) atau OFF (Navigasi)

; ⏮️ Previous Track → RWin + Numpad 7 / Home
RWin & Numpad7::
RWin & NumpadHome::Send "{Media_Prev}"

; ⏯️ Play / Pause → RWin + Numpad 4 / Left
RWin & Numpad4::
RWin & NumpadLeft::Send "{Media_Play_Pause}"

; ⏭️ Next Track → RWin + Numpad 1 / End
RWin & Numpad1::
RWin & NumpadEnd::Send "{Media_Next}"

; --- [ VOLUME CONTROLS ] ---

; 🔇 Mute → RWin + F9
RWin & F9::Send "{Volume_Mute}"

; 🔉 Volume Down → RWin + F10
RWin & F10::Send "{Volume_Down 2}"

; 🔊 Volume Up → RWin + F11
RWin & F11::Send "{Volume_Up 2}"

; --- [ TANDA SCRIPT AKTIF ] ---
TrayTip "Riku Shortcut v4.0", "Sistem & Media Control Siap!", 1